import json
from collections import Counter
from pathlib import Path
from endless_voices import assessment as a, openai_judge as j
r=Path('outputs/generator-benchmark-v1')
read=a.read_json
manifest=Path('data/pilot-v1/samples/manifest.json')
records=a.load_dataset(manifest,'validation')
ids=read(r/'selection.json')['ids']
assert len(ids)==len(set(ids))==48 and set(ids)==set(records)
summary={'models':{},'judge':{}}
for model in ['gpt-6-sol','gemma31b','claude-sonnet-5']:
 run,prompts,responses=a.load_run(r/'runs'/model,manifest,records,'validation')
 assert run['dataset']['sample_ids']==ids
 for path,digest in run['raw_artifacts_sha256'].items(): assert a.file_hash(Path(path))==digest
 assert set(responses)==set(ids)
 for sid,row in responses.items():
  raw=read(r/model/(sid+'.result.json'))
  assert row['response']==raw['response'] and row['status']==raw['status']
  if model!='gemma31b':
   api=raw['api_response']
   if model=='gpt-6-sol': text=''.join(p.get('text','') for m in api['output'] if m['type']=='message' for p in m['content'] if p['type']=='output_text')
   else: text=''.join(p['text'] for p in api['content'] if p['type']=='text')
   assert text==raw['response']
 summary['models'][model]={'statuses':dict(Counter(x['status'] for x in responses.values())), 'cost_usd':sum(x.get('estimated_cost_usd') or 0 for x in responses.values()), 'peak_memory_bytes':max(x.get('peak_memory_bytes',0) for x in responses.values())}
s=read(r/'sol-judge/settings.json')
assert s['code_sha256']==a.file_hash(Path(j.__file__))
assert s['judge_code_sha256']==a.file_hash(Path(j.__file__).with_name('judge.py'))
report=read(r/'report/report.json')
trials=report['trials']
assert len(trials)==len({t['trial_id'] for t in trials})==290
for t in trials:
 path=r/'assessment'/t['path']; tid=t['trial_id']; public=read(path)
 assert a.file_hash(path)==s['trial_hashes'][tid]==t['trial_sha256']
 assert set(public)=={'trial_id','context','A','B'}
 assert public['context']==a.evaluation_messages(records[t['sample_id']])
 if t['kind'] in ('primary','reversed'):
  assert public[t['original']]==records[t['sample_id']]['messages'][-1]['content']
  assert public['B' if t['original']=='A' else 'A']==read(r/t['condition']/(t['sample_id']+'.result.json'))['response']
 req=r/'sol-judge/gpt-6-sol'/f'{tid}.request.json'; result=read(req.with_name(f'{tid}.result.json'))
 assert read(req)==j.payload('gpt-6-sol',public,s['instructions'])
 assert result['request_sha256']==a.file_hash(req) and result['trial_sha256']==a.file_hash(path)
 assert j.assessment(result['api_response'])['choice']==result['choice']==t['choice']
 assert result['estimated_cost_usd']==j.charge('gpt-6-sol',result['api_response'])
summary['judge']={'cost_usd':j.spent(r/'sol-judge'),'statuses':dict(Counter(t['status'] for t in trials)),'returned_models':dict(Counter(t['api_response']['model'] for t in trials))}
for model in summary['models']:
 ts=[t for t in trials if t['condition']==model]
 summary['models'][model]['assessment_counts']={stage:dict(Counter(t['outcome'] for t in ts if t['kind']==stage)) for stage in ('primary','reversed')}
 summary['models'][model]['recognized']=sum(t['recognized_source'] for t in ts)
summary['total_api_usd']=summary['judge']['cost_usd']+sum(x['cost_usd'] for x in summary['models'].values())
a.write_json(r/'verification.json',summary)
print(json.dumps(summary,indent=2))
for t in trials:
 if t['kind']=='reversed' and t['outcome']!='correct':
  print('POSITION CHANGE',t['condition'],t['sample_id'],t['reason'])
  p=next(p for p in trials if p['kind']=='primary' and p['condition']==t['condition'] and p['sample_id']==t['sample_id'])
  print('PRIMARY REASON',p['reason'])
