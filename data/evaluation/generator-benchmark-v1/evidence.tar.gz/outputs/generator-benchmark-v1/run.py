import json
import subprocess
import sys
import time
from pathlib import Path

root = Path('outputs/generator-benchmark-v1')
commands = [
    ['data/local/screen-env/bin/python', 'scripts/screen_generators.py', 'local', '--root', str(root), '--config', str(root / 'gemma31b-config.json')],
    ['.venv/bin/python', 'scripts/benchmark_generators.py', 'hosted', '--root', str(root)],
    ['.venv/bin/python', 'scripts/benchmark_generators.py', 'export', '--root', str(root)],
    ['.venv/bin/python', '-m', 'endless_voices.openai_judge', '--public', str(root / 'assessment/public'), '--output', str(root / 'sol-judge'), '--models', 'gpt-6-sol', '--budget', '2', '--limit', '1000'],
    ['.venv/bin/python', '-m', 'endless_voices.assessment', 'report', '--pack', str(root / 'assessment'), '--review', str(root / 'sol-judge/gpt-6-sol/review.json'), '--output', str(root / 'report')],
]
for index, command in enumerate(commands):
    if index == 4:
        state = json.loads((root / 'sol-judge/state.json').read_text())
        if not state.get('complete'):
            print('Judge stopped:', state, flush=True)
            sys.exit(1)
    with (root / f'stage-{index}-started.json').open('x') as h:
        json.dump({'command': command, 'started_at': time.time()}, h, indent=2)
    print('Starting stage', index, flush=True)
    with (root / f'stage-{index}.log').open('x') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    with (root / f'stage-{index}-finished.json').open('x') as h:
        json.dump({'returncode': result.returncode, 'finished_at': time.time()}, h)
    if result.returncode:
        print('Stopped at stage', index, 'returncode', result.returncode, flush=True)
        sys.exit(result.returncode)
print('Complete: generation, blinded assessments, and report saved', flush=True)
