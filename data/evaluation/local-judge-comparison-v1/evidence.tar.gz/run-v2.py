"""Evaluate Mistral with explicit JSON-fence handling and unchanged judge prompts."""
import json,os,subprocess,time
from pathlib import Path
p=Path('outputs/mistral-judge-execution-v2.json')
if p.exists():raise SystemExit('Execution record exists')
r={'started_at':time.time(),'change':'Accept a single enclosing JSON Markdown fence; strict fields unchanged; raw output preserved. Original smoke retained.','stages':[]}
def save():
 t=p.with_suffix('.tmp');t.write_text(json.dumps(r,indent=2)+'\n');t.replace(p)
save()
base=['data/local/judge-env/bin/python','-m','endless_voices.judge','--instructions','outputs/agent-calibration-pack-v1/public/instructions.txt','--model-config','configs/judge-mistral-small-24b.json','--reviewer-id','mistral-small-24b-fence-validation-v2','--allow-json-fence']
for stage in ('smoke','primary','reversed','controls'):
 out=f'outputs/judge-candidates-mistral-small-24b-{stage}-v2'
 cmd=base+['--trials',f'outputs/agent-calibration-pack-v1/public/{"primary" if stage=="smoke" else stage}','--output',out]+(['--limit','1'] if stage=='smoke' else [])
 row={'stage':stage,'command':cmd,'started_at':time.time()};r['stages'].append(row);save()
 try:row['returncode']=subprocess.run(cmd,env={**os.environ,'PYTHONPATH':'src'},timeout=3600).returncode
 except subprocess.TimeoutExpired:row.update(returncode=None,error='Process time budget exceeded')
 row['finished_at']=time.time();save()
 if stage=='smoke':
  if row.get('returncode')!=0:break
  d=json.loads((Path(out)/'review.json').read_text())
  if max(x.get('peak_memory_gb',0) for x in d['reviews'])>20:r['stop_reason']='Smoke exceeds 20 GB MLX memory budget';break
r['finished_at']=time.time();save()
