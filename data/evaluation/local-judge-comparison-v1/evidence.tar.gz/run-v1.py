"""Run pinned local judge candidates sequentially and preserve execution status."""
import json
import os
from pathlib import Path
import subprocess
import time

root=Path.cwd()
record_path=root/'outputs/judge-candidates-execution-v1.json'
if record_path.exists():raise SystemExit('Execution record already exists')
record={'started_at':time.time(),'scope':'validation only; fixed existing prompts and reviews','stages':[]}
def save():
 tmp=record_path.with_suffix('.tmp');tmp.write_text(json.dumps(record,indent=2)+'\n');tmp.replace(record_path)
def execute(label,cmd,timeout):
 row={'label':label,'command':cmd,'started_at':time.time()};record['stages'].append(row);save()
 print('Starting',label,flush=True)
 try:row['returncode']=subprocess.run(cmd,env={**os.environ,'PYTHONPATH':'src'},timeout=timeout).returncode
 except subprocess.TimeoutExpired:row.update(returncode=None,error='Process time budget exceeded; stopped without retry')
 row['finished_at']=time.time();save();print('Finished',label,row.get('returncode'),flush=True)
 return row.get('returncode')==0
save()
for name in ('qwen3-30b','mistral-small-24b'):
 cfgpath=f'configs/judge-{name}.json';cfg=json.loads(Path(cfgpath).read_text())
 if not execute(name+' download',['data/local/judge-env/bin/hf','download',cfg['source'],'--revision',cfg['revision'],'--cache-dir','data/local/hub','--quiet'],7200):continue
 base=['data/local/judge-env/bin/python','-m','endless_voices.judge','--instructions','outputs/agent-calibration-pack-v1/public/instructions.txt','--model-config',cfgpath,'--reviewer-id',name+'-validation-v1']
 smoke=f'outputs/judge-candidates-{name}-smoke-v1'
 if not execute(name+' smoke',base+['--trials','outputs/agent-calibration-pack-v1/public/primary','--limit','1','--output',smoke],600):continue
 reviews=json.loads((Path(smoke)/'review.json').read_text())['reviews']
 peak=max(r.get('peak_memory_gb',0) for r in reviews)
 record.setdefault('smoke_memory_gb',{})[name]=peak;save()
 if peak>20:
  record.setdefault('stopped_candidates',{})[name]='Smoke exceeded 20 GB MLX peak memory budget';save();continue
 for stage in ('primary','reversed','controls'):
  execute(name+' '+stage,base+['--trials',f'outputs/agent-calibration-pack-v1/public/{stage}','--output',f'outputs/judge-candidates-{name}-{stage}-v1'],3600)
record['finished_at']=time.time();save()
