import json
from collections import Counter
from pathlib import Path
from endless_voices.assessment import file_hash,read_json,write_json
from endless_voices import openai_judge,anthropic_judge
pack=Path('outputs/agent-calibration-pack-v1'); private=read_json(pack/'private.json')
trials={t['trial_id']:t for t in private['trials']}
summary={}
for root,module in [(Path('outputs/openai-judge-validation-v1'),openai_judge),(Path('outputs/anthropic-judge-validation-v2'),anthropic_judge)]:
 settings=read_json(root/'settings.json')
 assert settings['code_sha256']==file_hash(Path(module.__file__))
 assert settings['judge_code_sha256']==file_hash(Path('src/endless_voices/judge.py'))
 for model in module.RATES:
  folder=root/model; rows={p.name.removesuffix('.result.json'):read_json(p) for p in folder.glob('*.result.json')}
  assert set(rows)==set(trials)=={p.name.removesuffix('.request.json') for p in folder.glob('*.request.json')}
  report=read_json(folder/'review.json');assert len(report['reviews'])==98
  assert {r['trial_id']:r for r in report['reviews']}==rows
  counts={}; costs=0; versions=Counter(); recognition=Counter(); usage=Counter()
  for tid,r in rows.items():
   t=trials[tid]; path=pack/t['path']; req=folder/f'{tid}.request.json'
   assert file_hash(path)==t['trial_sha256']==settings['trial_hashes'][tid]==r['trial_sha256']
   assert r['request_sha256']==file_hash(req)
   assert read_json(req)==module.payload(model,read_json(path),settings['instructions'])
   answer=module.assessment(r['api_response'])
   assert all(r[k]==v for k,v in answer.items()) and r['status']=='ok'
   assert r['estimated_cost_usd']==module.charge(model,r['api_response'])
   costs+=r['estimated_cost_usd'];versions[r['api_response']['model']]+=1
   for key,value in r['api_response']['usage'].items():
    if isinstance(value,int): usage[key]+=value
   outcome='abstain' if r['choice']=='abstain' else 'correct' if r['choice']==t['original'] else 'incorrect'
   counts.setdefault(t['kind'],Counter())[outcome]+=1
   if r['recognized_source']: recognition[t['kind']]+=1
  pairs=[]
  for tid,t in trials.items():
   if t['kind']!='primary':continue
   rev=next(x for x in trials.values() if x['kind']=='reversed' and x['sample_id']==t['sample_id'])
   a,b=rows[tid],rows[rev['trial_id']]
   ac=a['choice'];bc=b['choice']
   same=(ac==bc=='abstain') or (ac!='abstain' and bc!='abstain' and ac!=bc)
   if not same:pairs.append({'sample_id':t['sample_id'],'primary':a,'reversed':b})
  summary[model]={'counts':counts,'recognized':recognition,'estimated_usd':costs,'returned_models':versions,'usage':usage,'position_changes':pairs,'verified_trials':len(rows)}
write_json(Path('outputs/hosted-judge-comparison-v1/verification-reproduced.json'),summary)
for m,d in summary.items():
 print(m,{k:v for k,v in d.items() if k!='position_changes'})
 print('changes',[(p['sample_id'],p['primary']['choice'],p['reversed']['choice']) for p in d['position_changes']])
 for p in d['position_changes']:
  print('primary reason',p['primary']['reason']);print('reversed reason',p['reversed']['reason'])
