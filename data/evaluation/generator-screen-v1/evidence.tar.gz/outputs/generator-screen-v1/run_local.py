import json,subprocess,os,time
from pathlib import Path
root=Path('outputs/generator-screen-v1')
configs=[]
for name,label in [('judge-model','qwen14b'),('judge-qwen3-30b','qwen30b'),('judge-mistral-small-24b','mistral24b')]:
 d=json.loads(Path('configs/'+name+'.json').read_text());d['label']=label;configs.append(d)
for d,label in zip(json.loads((root/'new-models.json').read_text()),['gemma26b','gemma31b','qwen36_27b']):
 d['label']=label;d['path']=str(Path('data/local/hub')/('models--'+d['source'].replace('/','--'))/'snapshots'/d['revision']);configs.append(d)
record=[]
for cfg in configs:
 p=root/(cfg['label']+'-config.json');p.open('x').write(json.dumps(cfg,indent=2)+'\n')
 item={'config':str(p),'started_at':time.time()};record.append(item)
 if not Path(cfg['path']).exists():
  cmd=['data/local/screen-env/bin/hf','download',cfg['source'],'--revision',cfg['revision'],'--cache-dir','data/local/hub','--include','*.json','*.safetensors','*.model','*.txt','*.jinja']
  item['download_command']=cmd
  with (root/(cfg['label']+'-download.log')).open('x') as out: result=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
  item['download_returncode']=result.returncode
  if result.returncode:break
 cmd=['data/local/screen-env/bin/python','scripts/screen_generators.py','local','--config',str(p)]
 item['command']=cmd
 with (root/(cfg['label']+'-execution.log')).open('x') as out: result=subprocess.run(cmd,env={**os.environ,'PYTHONPATH':'src'},stdout=out,stderr=subprocess.STDOUT)
 item['returncode']=result.returncode;item['finished_at']=time.time()
 (root/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
 print(cfg['label'],result.returncode,flush=True)
(root/'local-complete.json').write_text(json.dumps({'stages':record})+'\n')
