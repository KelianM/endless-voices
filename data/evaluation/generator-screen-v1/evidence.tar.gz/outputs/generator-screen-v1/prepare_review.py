import json,secrets,string
from pathlib import Path
root=Path('outputs/generator-screen-v1')
read=lambda p:json.loads(p.read_text())
models=['qwen4b-baseline','qwen14b','qwen30b','mistral24b-v2','gemma26b','gemma31b-v2','qwen36_27b-v2','gpt-6-luna','gpt-6-sol','claude-sonnet-5']
secrets.SystemRandom().shuffle(models)
key={letter:model for letter,model in zip(string.ascii_uppercase,models)}
(root/'review-key.json').open('x').write(json.dumps(key,indent=2)+'\n')
originals=read(root/'originals.json');prompts=read(root/'prompts.json')
for index,prompt in enumerate(prompts,1):
 sid=prompt['sample_id'];lines=[f'# Scene {index}',json.dumps(prompt['messages'],ensure_ascii=False,indent=2),'Original continuation:',originals[sid]['messages'][-1]['content']]
 for label,model in key.items():
  if model=='qwen4b-baseline':row=next(x for x in read(root/'qwen4b-baseline.json')['responses'] if x['sample_id']==sid)
  else:
   path=root/model/(sid+'.result.json')
   row=read(path) if path.exists() else {'status':'missing','response':'No completed record'}
  lines += [f'## Candidate {label} ({row["status"]})',row['response']]
 (root/f'blind-scene-{index}.md').open('x').write('\n\n'.join(lines)+'\n')
print('Four anonymous review pages prepared; keep review-key.json private until notes saved')
