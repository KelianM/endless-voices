import json,subprocess,os,time
from pathlib import Path
r=Path('outputs/generator-screen-v1')
steps=[]
for label in ('gemma31b','qwen36_27b','mistral24b'):
 cfg=json.loads((r/(label+'-config.json')).read_text());cfg['label']=label+'-v2'
 if label=='mistral24b':cfg['tokenizer_options']={'fix_mistral_regex':True}
 p=r/(label+'-config-v2.json');p.open('x').write(json.dumps(cfg,indent=2)+'\n')
 record={'label':label,'reason':'missing weight download' if label!='mistral24b' else 'explicit tokenizer regex correction','started_at':time.time()};steps.append(record)
 if label!='mistral24b':
  cmd=['data/local/screen-env/bin/hf','download',cfg['source'],'--revision',cfg['revision'],'--cache-dir','data/local/hub']
  record['download_command']=cmd
  with (r/(label+'-download-v2.log')).open('x') as log:record['download_returncode']=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT).returncode
  if record['download_returncode']:break
 cmd=['data/local/screen-env/bin/python','scripts/screen_generators.py','local','--config',str(p)]
 record['generation_command']=cmd
 with (r/(label+'-execution-v2.log')).open('x') as log:record['returncode']=subprocess.run(cmd,env={**os.environ,'PYTHONPATH':'src'},stdout=log,stderr=subprocess.STDOUT).returncode
 record['finished_at']=time.time();(r/'execution-v2.json').write_text(json.dumps(steps,indent=2)+'\n');print(label,record['returncode'],flush=True)
(r/'local-complete-v2.json').write_text(json.dumps(steps,indent=2)+'\n')
