import hashlib,json,statistics
from pathlib import Path
r=Path('outputs/generator-screen-v1')
read=lambda p:json.loads(p.read_text())
def sha(p):
 with p.open('rb') as h:return hashlib.file_digest(h,'sha256').hexdigest()
key=read(r/'review-key.json');prompts=read(r/'prompts.json');ids=[p['sample_id'] for p in prompts];assert len(set(ids))==4
notes=read(r/'qualitative-notes-blind.json')
assert sha(r/'qualitative-notes-blind.json')==read(r/'review-reveal-record.json')['notes_sha256_before_reveal']
assert all(set(notes[f'scene_{i}'])==set(key) for i in range(1,5))
code_hashes={sha(r/'screen_generators.py'),sha(Path('scripts/screen_generators.py'))}
summary={}
for letter,label in key.items():
 if label=='qwen4b-baseline':
  rows=read(r/(label+'.json'))['responses']
 else:
  folder=r/label;settings=read(folder/'settings.json');rows=[read(folder/(sid+'.result.json')) for sid in ids]
  assert settings['code_sha256'] in code_hashes
  assert settings['prompts_sha256']==sha(r/'prompts.json')
  if 'model_files_sha256' in settings:
   for name,digest in settings['model_files_sha256'].items():assert sha(Path(settings['path'])/name)==digest
   for prompt in prompts:
    saved=read(folder/(prompt['sample_id']+'.prompt.json'));assert saved['messages']==prompt['messages']
    assert len(saved['input_ids'])+settings['max_output_tokens']<=settings['context_ceiling']
  else:
   for prompt,row in zip(prompts,rows):
    req=read(folder/(prompt['sample_id']+'.request.json'))['body']
    if 'input' in req:
     assert req['input']==prompt['messages']
     raw=''.join(p.get('text','') for item in row['api_response'].get('output',[]) if item.get('type')=='message' for p in item.get('content',[]) if p.get('type')=='output_text')
    else:
     assert req['system']==prompt['messages'][0]['content'] and req['messages']==prompt['messages'][1:]
     raw=''.join(p.get('text','') for p in row['api_response']['content'] if p['type']=='text')
    assert raw==row['response']
 assert {x['sample_id'] for x in rows}==set(ids) and len(rows)==4
 assert all(x['status']=='ok' for x in rows)
 summary[label]={'letter':letter,'completed':4,'failed':0,'missing':0,
  'words_by_sample':{x['sample_id']:len(x['response'].split()) for x in rows},
  'mean_words':statistics.mean(len(x['response'].split()) for x in rows),
  'max_mlx_memory_bytes':max(x.get('peak_memory_bytes',0) for x in rows) or None,
  'elapsed_seconds':sum(x['elapsed_seconds'] for x in rows),
  'estimated_api_cost_usd':sum(x.get('estimated_cost_usd') or 0 for x in rows)}
(r/'verification.json').open('x').write(json.dumps(summary,indent=2)+'\n')
print('Verified all 40 screen responses, input contexts, local weight hashes and pre-reveal notes')
print(json.dumps({k:{'mean_words':v['mean_words'],'peak_GB':(v['max_mlx_memory_bytes'] or 0)/1e9} for k,v in summary.items()}))
